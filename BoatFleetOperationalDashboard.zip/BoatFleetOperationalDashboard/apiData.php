<?php
header('Content-Type: application/json');

$host = 'localhost';
$db   = 'daks_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);

    // Get date range from GET parameters (default if empty)
    $start = $_GET['start'] ?? '2026-01-01';
    $end   = $_GET['end'] ?? date('Y-m-d');

    // 1. Trips per Boat
    $stmt = $pdo->prepare("
        SELECT bt.boatid, b.boatno, COUNT(*) AS trips
        FROM boattrip bt
        JOIN boat b ON b.boatid = bt.boatid
        WHERE bt.departure BETWEEN :start AND :end
        GROUP BY bt.boatid, b.boatno
        ORDER BY trips DESC
        LIMIT 10
    ");
    $stmt->execute(['start' => $start, 'end' => $end]);
    $rows = $stmt->fetchAll();
    $tripLabels = [];
    $tripData = [];
    foreach ($rows as $row) {
        $tripLabels[] = $row['boatno'];
        $tripData[] = (int)$row['trips'];
    }

    // 2. Boat Availability Status
    $stmt = $pdo->query("
        SELECT 
            SUM(isavailable = 1) AS available,
            SUM(isavailable = 0) AS unavailable
        FROM boat
    ");
    $availability = $stmt->fetch();

    // 3. Boat Distribution by Size
    $stmt = $pdo->query("
        SELECT boatsize, COUNT(*) AS count
        FROM boat
        GROUP BY boatsize
    ");
    $distribution = $stmt->fetchAll();
    $sizeLabels = [];
    $sizeData = [];
    foreach ($distribution as $row) {
        $sizeLabels[] = $row['boatsize'];
        $sizeData[] = (int)$row['count'];
    }

    // 4. Average Trip Duration
    $stmt = $pdo->prepare("
        SELECT DATE(departure) AS trip_date,
               AVG(TIMESTAMPDIFF(MINUTE, departure, arrival)/60) AS avg_duration
        FROM boattrip
        WHERE departure BETWEEN :start AND :end
        GROUP BY DATE(departure)
        ORDER BY DATE(departure)
    ");
    $stmt->execute(['start' => $start, 'end' => $end]);
    $durations = $stmt->fetchAll();
    $durationLabels = [];
    $durationData = [];
    foreach ($durations as $row) {
        $durationLabels[] = $row['trip_date'];
        $durationData[] = round((float)$row['avg_duration'], 2);
    }

    // Output JSON matching the HTML dashboard structure
    echo json_encode([
        "tripsPerBoat" => [
            "labels" => $tripLabels,
            "data"   => $tripData
        ],
        "boatAvailability" => [
            "available" => (int)$availability['available'],
            "unavailable" => (int)$availability['unavailable']
        ],
        "boatDistribution" => [
            "labels" => $sizeLabels,
            "data"   => $sizeData
        ],
        "avgTripDuration" => [
            "labels" => $durationLabels,
            "data"   => $durationData
        ]
    ]);

} catch (\PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>