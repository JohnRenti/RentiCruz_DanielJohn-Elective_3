<?php
header('Content-Type: application/json');

$pdo = new PDO("mysql:host=localhost;dbname=daks_db;charset=utf8", "root", "", [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
]);

$start = $_GET['start'] ?? '2026-01-01';
$end   = $_GET['end'] ?? date('Y-m-d');

/* =========================
   1. REVENUE MONTHLY
========================= */
$stmt = $pdo->prepare("
SELECT DATE_FORMAT(departure,'%Y-%m') as month,
SUM(boatamount) as total
FROM boattrip
WHERE departure BETWEEN :start AND :end
GROUP BY month
");
$stmt->execute(compact('start','end'));
$revMonth = $stmt->fetchAll();

/* =========================
   2. PASSENGER TRENDS
========================= */
$stmt = $pdo->prepare("
SELECT DATE(departure) as d,
SUM(noofpassengers) as total
FROM boattrip
WHERE departure BETWEEN :start AND :end
GROUP BY d
");
$stmt->execute(compact('start','end'));
$passenger = $stmt->fetchAll();

/* =========================
   3. REVENUE BY BOAT SIZE
========================= */
$stmt = $pdo->query("
SELECT b.boatsize, SUM(bt.boatamount) as total
FROM boattrip bt
JOIN boat b ON b.boatid = bt.boatid
GROUP BY b.boatsize
");
$boatSize = $stmt->fetchAll();

/* =========================
   4. PAID VS UNPAID
========================= */
$stmt = $pdo->query("
SELECT 
SUM(ispaid=1) as paid,
SUM(ispaid=0) as unpaid
FROM boattrip
");
$paid = $stmt->fetch();

/* =========================
   5. TOP DRIVERS
========================= */
$stmt = $pdo->query("
SELECT d.name, COUNT(*) as trips
FROM boattrip bt
JOIN driver d ON d.driverid = bt.driverid
GROUP BY bt.driverid
ORDER BY trips DESC LIMIT 10
");
$drivers = $stmt->fetchAll();

/* =========================
   6. CANCELLED TRIPS
========================= */
$stmt = $pdo->query("
SELECT d.name, COUNT(*) as total
FROM boattrip bt
JOIN driver d ON d.driverid = bt.driverid
WHERE bt.datecancelled IS NOT NULL
GROUP BY bt.driverid
");
$cancelled = $stmt->fetchAll();

/* =========================
   7. SAFETY CHECKS
========================= */
$stmt = $pdo->query("
SELECT 
AVG(checklifevest)*100 as lifevest,
AVG(checkfireextandsand)*100 as fire,
AVG(checktrashbin)*100 as trash,
AVG(checkgas)*100 as gas
FROM boattrip
");
$safety = $stmt->fetch();

/* =========================
   8. SPEED PER BOAT
========================= */
$stmt = $pdo->query("
SELECT boatno, iot_speedKnots FROM boat
");
$speed = $stmt->fetchAll();

/* =========================
   9. PEAK HOURS
========================= */
$stmt = $pdo->query("
SELECT HOUR(departure) as hr, COUNT(*) as total
FROM boattrip
GROUP BY hr
");
$peak = $stmt->fetchAll();

/* =========================
   10. DRIVER WORKLOAD VS BOAT CAPACITY
========================= */
$stmt = $pdo->query("SELECT d.name, COUNT(bt.boatid) as trips, AVG(b.boatcapacity) as avg_capacity
FROM boattrip bt
JOIN driver d ON d.driverid = bt.driverid
JOIN boat b ON b.boatid = bt.boatid
GROUP BY d.name");
$driverWorkload = $stmt->fetchAll();

/* =========================
   11. INSPECTIONS BY PERSONNEL
========================= */
$stmt = $pdo->query("SELECT inspectedby, COUNT(*) as inspections
FROM boattrip
GROUP BY inspectedby");
$inspections = $stmt->fetchAll();

/* =========================
   12. DRIVER-TO-BOAT ASSIGNMENT CONSISTENCY
========================= */
$stmt = $pdo->query("SELECT b.driverid as default_driver, bt.driverid as actual_driver, COUNT(*) as mismatches
FROM boattrip bt
JOIN boat b ON b.boatid = bt.boatid
WHERE b.driverid != bt.driverid
GROUP BY b.driverid, bt.driverid");
$driverConsistency = $stmt->fetchAll();

/* =========================
   13. REVENUE BY TOUR TYPE
========================= */
$stmt = $pdo->query("SELECT islandtourtype, SUM(boatamount) as total
FROM boattrip
GROUP BY islandtourtype");
$tourRevenue = $stmt->fetchAll();

/* =========================
   14. BOAT CAPACITY VS ACTUAL PASSENGERS
========================= */
$stmt = $pdo->query("SELECT b.boatcapacity, SUM(bt.noofpassengers) as passengers
FROM boattrip bt
JOIN boat b ON b.boatid = bt.boatid
GROUP BY b.boatcapacity");
$capacityUtilization = $stmt->fetchAll();

/* =========================
   15. PAYMENT COMPLETION RATE
========================= */
$stmt = $pdo->query("SELECT SUM(ispaid=1) as paid, SUM(ispaid=0) as unpaid
FROM boattrip");
$paymentRate = $stmt->fetch();

/* =========================
   OUTPUT JSON
========================= */
echo json_encode([
    "revenueMonthly" => [
        "labels" => array_column($revMonth,'month'),
        "data" => array_column($revMonth,'total')
    ],
    "passengerTrends" => [
        "labels" => array_column($passenger,'d'),
        "data" => array_column($passenger,'total')
    ],
    "revenueBoatSize" => [
        "labels" => array_column($boatSize,'boatsize'),
        "data" => array_column($boatSize,'total')
    ],
    "paidTrips" => $paid,
    "topDrivers" => [
        "labels" => array_column($drivers,'name'),
        "data" => array_column($drivers,'trips')
    ],
    "cancelledTrips" => [
        "labels" => array_column($cancelled,'name'),
        "data" => array_column($cancelled,'total')
    ],
    "safetyCompliance" => $safety,
    "speedPerBoat" => [
        "labels" => array_column($speed,'boatno'),
        "data" => array_column($speed,'iot_speedKnots')
    ],
    "peakHours" => [
        "labels" => array_column($peak,'hr'),
        "data" => array_column($peak,'total')
    ],
    "driverWorkload" => [
        "labels" => array_column($driverWorkload, 'name'),
        "data" => array_column($driverWorkload, 'trips'),
        "avgCapacity" => array_column($driverWorkload, 'avg_capacity')
    ],
    "inspections" => [
        "labels" => array_column($inspections, 'inspectedby'),
        "data" => array_column($inspections, 'inspections')
    ],
    "driverConsistency" => $driverConsistency,
    "tourRevenue" => [
        "labels" => array_column($tourRevenue, 'islandtourtype'),
        "data" => array_column($tourRevenue, 'total')
    ],
    "capacityUtilization" => [
        "labels" => array_column($capacityUtilization, 'boatcapacity'),
        "data" => array_column($capacityUtilization, 'passengers')
    ],
    "paymentRate" => $paymentRate
]);
?>