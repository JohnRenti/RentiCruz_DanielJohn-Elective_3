<?php
header('Content-Type: application/json');

$host = 'localhost';
$db   = 'daks_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
    
    // Fetch data
    $stmt = $pdo->query("SELECT 
    COUNT(*) AS tboat, 
    bt.boatid, 
    b.boatno 
FROM 
    boattrip AS bt
JOIN 
    boat AS b ON b.boatid = bt.boatid
WHERE 
    bt.boatid <> 0
GROUP BY 
    bt.boatid, b.boatno
ORDER BY 
    tboat DESC
LIMIT 10;");
    $rows = $stmt->fetchAll();

    // Prepare arrays for Chart.js
    $labels = [];
    $salesData = [];
    $tripsData = [];

    foreach ($rows as $row) {
        $labels[] = $row['boatno'];
        $salesData[] = (int)$row['tboat'] * 1200;
        $tripsData[] = (int)$row['tboat'];
    }

    // Structure the JSON
    echo json_encode([
        "labels" => $labels,
        "datasets" => [
            [
                "type" => "bar",
                "label" => "Sales (Bar)",
                "data" => $salesData,
                "backgroundColor" => "rgba(54, 162, 235, 0.6)",
                "borderColor" => "rgb(54, 162, 235)",
                "borderWidth" => 1
            ],
            [
                "type" => "line",
                "label" => "Revenue (Line)",
                "data" => $tripsData,
                "borderColor" => "rgb(255, 99, 132)",
                "backgroundColor" => "transparent",
                "tension" => 0.3,
                "fill" => false
            ]
        ]
    ]);

} catch (\PDOException $e) {
    echo json_encode(["error" => $e->getMessage()]);
}
?>